<?php
/**
 * Noyona Order Tracking MU plugin runtime.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Noyona_Order_Tracking' ) ) {
	final class Noyona_Order_Tracking {
		const META_KEY_EVENTS  = '_noyona_tracking_events';
		const META_KEY_CARRIER = '_noyona_tracking_carrier';
		const META_KEY_NUMBER  = '_noyona_tracking_number';
		const META_KEY_URL     = '_noyona_tracking_url';
		const META_KEY_NOTE    = '_noyona_tracking_note';
		const NONCE_FIELD      = 'noyona_ot_nonce';
		const NONCE_ACTION     = 'noyona_ot_save_order_tracking';

		/**
		 * @var Noyona_Order_Tracking|null
		 */
		private static $instance = null;

		/**
		 * @return Noyona_Order_Tracking
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * @return void
		 */
		private function __construct() {
			add_action( 'init', array( $this, 'register_custom_statuses' ) );
			add_filter( 'wc_order_statuses', array( $this, 'inject_custom_status_labels' ) );
			add_filter( 'woocommerce_reports_order_statuses', array( $this, 'register_statuses_for_reports' ) );

			add_action( 'add_meta_boxes_shop_order', array( $this, 'add_tracking_metabox' ) );
			add_action( 'woocommerce_process_shop_order_meta', array( $this, 'save_tracking_metabox' ), 30, 2 );
			add_action( 'woocommerce_order_status_changed', array( $this, 'capture_status_change_event' ), 20, 4 );

			add_action( 'admin_menu', array( $this, 'register_admin_page' ) );
			add_action( 'admin_post_noyona_ot_quick_update', array( $this, 'handle_quick_update' ) );
		}

		/**
		 * @return array<string, array<string, mixed>>
		 */
		public function get_order_status_filters() {
			return array(
				'to-pay'        => array(
					'label'          => __( 'To Pay', 'noyona-childtheme' ),
					'icon'           => 'fa-regular fa-credit-card',
					'statuses'       => array( 'pending', 'on-hold', 'failed' ),
					'preferred_slug' => 'pending',
				),
				'to-ship'       => array(
					'label'          => __( 'To Ship', 'noyona-childtheme' ),
					'icon'           => 'fa-solid fa-box-open',
					'statuses'       => array( 'to-ship', 'processing' ),
					'preferred_slug' => 'to-ship',
				),
				'to-receive'    => array(
					'label'          => __( 'To Receive', 'noyona-childtheme' ),
					'icon'           => 'fa-solid fa-truck-fast',
					'statuses'       => array( 'to-receive', 'at-hub', 'rider-assigned', 'out-for-delivery', 'shipped', 'in-transit' ),
					'preferred_slug' => 'to-receive',
				),
				'complete'      => array(
					'label'          => __( 'Complete', 'noyona-childtheme' ),
					'icon'           => 'fa-regular fa-circle-check',
					'statuses'       => array( 'completed' ),
					'preferred_slug' => 'completed',
				),
				'cancel-refund' => array(
					'label'          => __( 'Cancel / Refund', 'noyona-childtheme' ),
					'icon'           => 'fa-regular fa-circle-xmark',
					'statuses'       => array( 'cancelled', 'refunded' ),
					'preferred_slug' => 'cancelled',
				),
			);
		}

		/**
		 * @param string $default Default filter key.
		 * @return string
		 */
		public function get_selected_filter( $default = 'to-pay' ) {
			$filters = $this->get_order_status_filters();
			$key     = isset( $_GET['order_filter'] ) ? sanitize_key( wp_unslash( $_GET['order_filter'] ) ) : $default;

			if ( ! isset( $filters[ $key ] ) ) {
				return $default;
			}

			return $key;
		}

		/**
		 * @param string $filter_key Filter key.
		 * @return array<int, string>
		 */
		public function get_query_statuses_for_filter( $filter_key ) {
			$filters = $this->get_order_status_filters();
			if ( ! isset( $filters[ $filter_key ] ) ) {
				$filter_key = 'to-pay';
			}

			$target_statuses = array_map(
				'sanitize_key',
				(array) $filters[ $filter_key ]['statuses']
			);

			$available_statuses = $this->get_available_status_slugs();
			$resolved           = array_values(
				array_filter(
					$target_statuses,
					static function ( $slug ) use ( $available_statuses ) {
						return in_array( $slug, $available_statuses, true );
					}
				)
			);

			if ( empty( $resolved ) && in_array( 'pending', $available_statuses, true ) ) {
				return array( 'pending' );
			}

			return $resolved;
		}

		/**
		 * @return array<int, string>
		 */
		private function get_available_status_slugs() {
			$statuses = function_exists( 'wc_get_order_statuses' ) ? (array) wc_get_order_statuses() : array();

			return array_map(
				static function ( $status_key ) {
					$status_key = (string) $status_key;
					return sanitize_key( 0 === strpos( $status_key, 'wc-' ) ? substr( $status_key, 3 ) : $status_key );
				},
				array_keys( $statuses )
			);
		}

		/**
		 * Normalize timeline code aliases so equivalent logistics states share one step.
		 *
		 * @param string $code Timeline code.
		 * @return string
		 */
		private function normalize_timeline_code( $code ) {
			$code  = sanitize_key( (string) $code );
			$alias = array(
				'at-warehouse'                    => 'at-hub',
				'arrived-at-warehouse'            => 'at-hub',
				'parcel-arrived-at-warehouse'     => 'at-hub',
				'order-arrived-at-delivery-hub'   => 'at-hub',
				'your-parcel-has-arrived-at-the-warehouse' => 'at-hub',
				'your-parcel-has-arrived-at-the-hub'       => 'at-hub',
				'noyona-is-preparing-to-ship-your-order'   => 'preparing-shipment',
				'courier-has-picked-up-your-order'          => 'courier-picked-up',
				'parcel-picked-up-by-courier'               => 'courier-picked-up',
				'delivery-rider-has-been-assigned'         => 'out-for-delivery',
				'parcel-is-out-for-delivery'               => 'out-for-delivery',
				'rider-assigned'                 => 'out-for-delivery',
				'shipped'                        => 'out-for-delivery',
				'in-transit'                     => 'out-for-delivery',
			);

			return isset( $alias[ $code ] ) ? $alias[ $code ] : $code;
		}

		/**
		 * @param WC_Order|int $order Order object or ID.
		 * @return array<int, array<string, string>>
		 */
		public function get_timeline_rows( $order ) {
			$order = $this->ensure_order( $order );
			if ( ! $order ) {
				return array();
			}

			$template = $this->get_default_timeline_template();
			$events   = $this->get_events_for_order( $order, true );
			if ( empty( $events ) ) {
				return $this->build_template_rows_for_status( (string) $order->get_status(), $order, $template, array() );
			}

			$custom_codes = array();
			foreach ( $events as $event ) {
				$event_code = isset( $event['code'] ) ? $this->normalize_timeline_code( (string) $event['code'] ) : '';
				if ( '' === $event_code || isset( $template[ $event_code ] ) ) {
					continue;
				}
				$custom_codes[] = $event_code;
			}

			if ( ! empty( $custom_codes ) ) {
				return $this->build_rows_from_events( $events );
			}

			return $this->build_template_rows_for_status( (string) $order->get_status(), $order, $template, $events );
		}

		/**
		 * @param array<int, array<string, mixed>> $events Events list.
		 * @return array<int, array<string, string>>
		 */
		private function build_rows_from_events( $events ) {
			usort(
				$events,
				static function ( $left, $right ) {
					$left_ts  = isset( $left['event_date_gmt'] ) ? strtotime( (string) $left['event_date_gmt'] . ' UTC' ) : 0;
					$right_ts = isset( $right['event_date_gmt'] ) ? strtotime( (string) $right['event_date_gmt'] . ' UTC' ) : 0;
					return $right_ts <=> $left_ts;
				}
			);

			$rows = array();
			foreach ( $events as $index => $event ) {
				$label = isset( $event['label'] ) ? trim( (string) $event['label'] ) : '';
				if ( '' === $label ) {
					continue;
				}

				$rows[] = array(
					'label'      => $label,
					'date_label' => $this->format_date_label( isset( $event['event_date_gmt'] ) ? (string) $event['event_date_gmt'] : '' ),
					'state'      => ( 0 === $index ? 'is-current' : 'is-complete' ),
				);
			}

			return $rows;
		}

		/**
		 * @param string                                       $status_slug Order status slug.
		 * @param WC_Order                                     $order       Order object.
		 * @param array<string, string>                        $template    Timeline template.
		 * @param array<int, array<string, string|int|float>> $events      Events.
		 * @return array<int, array<string, string>>
		 */
		private function build_template_rows_for_status( $status_slug, $order, $template, $events ) {
			$event_by_code = array();
			foreach ( $events as $event ) {
				$event_code = isset( $event['code'] ) ? $this->normalize_timeline_code( (string) $event['code'] ) : '';
				if ( '' === $event_code || ! isset( $template[ $event_code ] ) ) {
					continue;
				}
				$event_by_code[ $event_code ] = $event;
			}

			$stage_code = $this->status_to_stage_code( $status_slug );
			$codes      = array_keys( $template );
			$current_at = array_search( $stage_code, $codes, true );
			if ( false === $current_at ) {
				$current_at = 0;
			}

			$rows = array();
			foreach ( $codes as $index => $code ) {
				$date_label = '';
				if ( isset( $event_by_code[ $code ]['event_date_gmt'] ) ) {
					$date_label = $this->format_date_label( (string) $event_by_code[ $code ]['event_date_gmt'] );
				} elseif ( 'placed' === $code && $order->get_date_created() instanceof WC_DateTime ) {
					$date_label = strtoupper( wp_date( 'M d, Y', $order->get_date_created()->getTimestamp() ) );
				}

				$state = 'is-pending';
				if ( $index < (int) $current_at ) {
					$state = 'is-complete';
				} elseif ( $index === (int) $current_at ) {
					$state = 'is-current';
				}

				$rows[] = array(
					'label'      => (string) $template[ $code ],
					'date_label' => $date_label,
					'state'      => $state,
				);
			}

			return $rows;
		}

		/**
		 * @param string $status_slug Order status.
		 * @return string
		 */
		private function status_to_stage_code( $status_slug ) {
			$status_slug = sanitize_key( (string) $status_slug );
			$map         = array(
				'pending'          => 'placed',
				'on-hold'          => 'placed',
				'failed'           => 'placed',
				'cancelled'        => 'placed',
				'refunded'         => 'delivered',
				'processing'       => 'preparing-shipment',
				'to-ship'          => 'preparing-shipment',
				'to-receive'       => 'courier-picked-up',
				'at-hub'           => 'at-hub',
				'rider-assigned'   => 'out-for-delivery',
				'out-for-delivery' => 'out-for-delivery',
				'shipped'          => 'out-for-delivery',
				'in-transit'       => 'out-for-delivery',
				'completed'        => 'delivered',
			);

			return isset( $map[ $status_slug ] ) ? $map[ $status_slug ] : 'placed';
		}

		/**
		 * @return array<string, string>
		 */
		public function get_default_timeline_template() {
			return array(
				'placed'           => __( 'Order has been placed', 'noyona-childtheme' ),
				'preparing-shipment' => __( 'Noyona is preparing to ship your order', 'noyona-childtheme' ),
				'courier-picked-up'  => __( 'Courier has picked up your order', 'noyona-childtheme' ),
				'at-hub'             => __( 'Order arrived at delivery hub', 'noyona-childtheme' ),
				'out-for-delivery'   => __( 'Out for delivery', 'noyona-childtheme' ),
				'delivered'        => __( 'Parcel has been delivered', 'noyona-childtheme' ),
			);
		}

		/**
		 * @param WC_Order|int $order Order object or ID.
		 * @param bool         $with_fallback Build fallback events when empty.
		 * @return array<int, array<string, string|int>>
		 */
		public function get_events_for_order( $order, $with_fallback = true ) {
			$order = $this->ensure_order( $order );
			if ( ! $order ) {
				return array();
			}

			$raw_events = $order->get_meta( self::META_KEY_EVENTS, true );
			$events     = $this->normalize_events( is_array( $raw_events ) ? $raw_events : array() );
			if ( ! empty( $events ) || ! $with_fallback ) {
				return $events;
			}

			return $this->generate_default_events_from_order( $order );
		}

		/**
		 * @param WC_Order|int $order Order object or ID.
		 * @return WC_Order|false
		 */
		private function ensure_order( $order ) {
			if ( $order instanceof WC_Order ) {
				return $order;
			}

			$order_id = absint( $order );
			if ( $order_id < 1 || ! function_exists( 'wc_get_order' ) ) {
				return false;
			}

			$resolved = wc_get_order( $order_id );
			return ( $resolved instanceof WC_Order ) ? $resolved : false;
		}

		/**
		 * @param array<int, array<string, mixed>> $events Raw events.
		 * @return array<int, array<string, string|int>>
		 */
		private function normalize_events( $events ) {
			$normalized = array();
			$template   = $this->get_default_timeline_template();
			$legacy_default_labels = array(
				'order has been placed',
				'noyona is preparing to ship your order',
				'courier has picked up your order',
				'your parcel has arrived at the warehouse',
				'your parcel has arrived at the hub',
				'order arrived at delivery hub',
				'delivery rider has been assigned',
				'parcel is out for delivery',
				'out for delivery',
				'parcel has been delivered',
			);
			foreach ( $events as $event ) {
				if ( ! is_array( $event ) ) {
					continue;
				}

				$label = isset( $event['label'] ) ? sanitize_text_field( (string) $event['label'] ) : '';
				if ( '' === $label ) {
					continue;
				}

				$code = isset( $event['code'] ) ? sanitize_key( (string) $event['code'] ) : '';
				if ( '' === $code ) {
					$code = sanitize_title( $label );
				}
				$code = $this->normalize_timeline_code( $code );
				$is_manual = ! empty( $event['is_manual'] ) ? 1 : 0;
				$label_lc = strtolower( trim( $label ) );
				$is_legacy_default_label = in_array( $label_lc, $legacy_default_labels, true );
				if ( isset( $template[ $code ] ) && ( 0 === $is_manual || $is_legacy_default_label ) ) {
					$label = (string) $template[ $code ];
				}

				$event_date_gmt = isset( $event['event_date_gmt'] ) ? $this->sanitize_gmt_datetime( (string) $event['event_date_gmt'] ) : '';
				if ( '' === $event_date_gmt ) {
					$event_date_gmt = gmdate( 'Y-m-d H:i:s' );
				}

				$normalized[] = array(
					'code'           => $code,
					'label'          => $label,
					'note'           => isset( $event['note'] ) ? sanitize_textarea_field( (string) $event['note'] ) : '',
					'event_date_gmt' => $event_date_gmt,
					'is_manual'      => $is_manual,
				);
			}

			usort(
				$normalized,
				static function ( $left, $right ) {
					$left_ts  = strtotime( (string) $left['event_date_gmt'] . ' UTC' );
					$right_ts = strtotime( (string) $right['event_date_gmt'] . ' UTC' );
					return $left_ts <=> $right_ts;
				}
			);

			return array_values( $normalized );
		}

		/**
		 * @param WC_Order $order Order object.
		 * @return array<int, array<string, string|int>>
		 */
		private function generate_default_events_from_order( $order ) {
			$events     = array();
			$created_at = $order->get_date_created();
			$created_gmt = $created_at instanceof WC_DateTime ? gmdate( 'Y-m-d H:i:s', $created_at->getTimestamp() ) : gmdate( 'Y-m-d H:i:s' );

			$events[] = array(
				'code'           => 'placed',
				'label'          => __( 'Order has been placed', 'noyona-childtheme' ),
				'note'           => '',
				'event_date_gmt' => $created_gmt,
				'is_manual'      => 0,
			);

			$current_code = $this->status_to_stage_code( (string) $order->get_status() );
			if ( 'placed' !== $current_code ) {
				$template = $this->get_default_timeline_template();
				$date_obj = $order->get_date_completed();
				if ( ! $date_obj instanceof WC_DateTime ) {
					$date_obj = $order->get_date_modified();
				}

				$events[] = array(
					'code'           => $current_code,
					'label'          => isset( $template[ $current_code ] ) ? (string) $template[ $current_code ] : ucwords( str_replace( '-', ' ', $current_code ) ),
					'note'           => '',
					'event_date_gmt' => $date_obj instanceof WC_DateTime ? gmdate( 'Y-m-d H:i:s', $date_obj->getTimestamp() ) : gmdate( 'Y-m-d H:i:s' ),
					'is_manual'      => 0,
				);
			}

			return $this->normalize_events( $events );
		}

		/**
		 * @param string $datetime_gmt GMT datetime.
		 * @return string
		 */
		private function format_date_label( $datetime_gmt ) {
			$datetime_gmt = $this->sanitize_gmt_datetime( $datetime_gmt );
			if ( '' === $datetime_gmt ) {
				return '';
			}

			$timestamp = strtotime( $datetime_gmt . ' UTC' );
			if ( false === $timestamp ) {
				return '';
			}

			return strtoupper( wp_date( 'M d, Y', $timestamp ) );
		}

		/**
		 * @param string $value Datetime string.
		 * @return string
		 */
		private function sanitize_gmt_datetime( $value ) {
			$value = trim( (string) $value );
			if ( '' === $value ) {
				return '';
			}

			$timestamp = strtotime( $value . ' UTC' );
			if ( false === $timestamp ) {
				$timestamp = strtotime( $value );
			}
			if ( false === $timestamp ) {
				return '';
			}

			return gmdate( 'Y-m-d H:i:s', $timestamp );
		}

		/**
		 * @param string $local_datetime Local datetime from datetime-local input.
		 * @return string
		 */
		private function local_input_to_gmt( $local_datetime ) {
			$local_datetime = trim( (string) $local_datetime );
			if ( '' === $local_datetime ) {
				return gmdate( 'Y-m-d H:i:s' );
			}

			try {
				$timezone = wp_timezone();
				$date_obj = new DateTime( $local_datetime, $timezone );
				$date_obj->setTimezone( new DateTimeZone( 'UTC' ) );
				return $date_obj->format( 'Y-m-d H:i:s' );
			} catch ( Exception $e ) {
				return gmdate( 'Y-m-d H:i:s' );
			}
		}

		/**
		 * @param string $gmt_datetime GMT datetime.
		 * @return string
		 */
		private function gmt_to_local_input( $gmt_datetime ) {
			$gmt_datetime = $this->sanitize_gmt_datetime( $gmt_datetime );
			if ( '' === $gmt_datetime ) {
				return '';
			}

			$timestamp = strtotime( $gmt_datetime . ' UTC' );
			if ( false === $timestamp ) {
				return '';
			}

			return wp_date( 'Y-m-d\TH:i', $timestamp, wp_timezone() );
		}

		/**
		 * @param int   $order_id Order ID.
		 * @param array $order    Order object or data.
		 * @return void
		 */
		public function save_tracking_metabox( $order_id, $order = null ) {
			$order_id = absint( $order_id );
			if ( $order_id < 1 ) {
				return;
			}

			if ( ! isset( $_POST[ self::NONCE_FIELD ] ) ) {
				return;
			}

			$nonce = sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) );
			if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
				return;
			}

			if ( ! current_user_can( 'edit_post', $order_id ) && ! current_user_can( 'edit_shop_orders' ) ) {
				return;
			}

			$order_object = $this->ensure_order( $order ? $order : $order_id );
			if ( ! $order_object ) {
				return;
			}

			$selected_stage = isset( $_POST['noyona_ot_stage'] ) ? sanitize_key( wp_unslash( $_POST['noyona_ot_stage'] ) ) : '';
			$status_map     = $this->get_stage_to_status_map();
			$stage_blocked  = false;
			if ( isset( $status_map[ $selected_stage ] ) ) {
				if ( ! $this->can_set_stage_for_order( $order_object, $selected_stage ) ) {
					$stage_blocked = true;
					$order_object->add_order_note( __( 'Tracking stage update skipped: order must be paid before moving to shipping/delivery stages.', 'noyona-childtheme' ) );
				}

				$next_status = sanitize_key( (string) $status_map[ $selected_stage ] );
				if ( ! $stage_blocked && '' !== $next_status && $next_status !== $order_object->get_status() ) {
					$order_object->set_status( $next_status );
				}
			}

			$events = $stage_blocked ? array() : $this->collect_events_from_request();
			if ( empty( $events ) ) {
				// Preserve fallback behavior for untouched historic orders.
				$events = $this->get_events_for_order( $order_object, true );
			}

			$order_object->update_meta_data( self::META_KEY_EVENTS, $events );

			$this->save_carrier_fields_from_request( $order_object );

			$order_object->save();
		}

		/**
		 * Pull carrier / tracking-number / URL / note from $_POST and persist to order meta.
		 * URL is auto-built from (carrier, number) when left blank and carrier is known.
		 *
		 * @param WC_Order $order_object Order object.
		 * @return void
		 */
		private function save_carrier_fields_from_request( $order_object ) {
			if ( ! isset( $_POST['noyona_ot_carrier'] )
				&& ! isset( $_POST['noyona_ot_number'] )
				&& ! isset( $_POST['noyona_ot_url'] )
				&& ! isset( $_POST['noyona_ot_note'] ) ) {
				return;
			}

			$carriers       = $this->get_carrier_definitions();
			$carrier_slug   = isset( $_POST['noyona_ot_carrier'] ) ? sanitize_key( wp_unslash( $_POST['noyona_ot_carrier'] ) ) : '';
			if ( ! isset( $carriers[ $carrier_slug ] ) ) {
				$carrier_slug = '';
			}
			$tracking_number = isset( $_POST['noyona_ot_number'] ) ? sanitize_text_field( wp_unslash( $_POST['noyona_ot_number'] ) ) : '';
			$tracking_url    = isset( $_POST['noyona_ot_url'] ) ? esc_url_raw( wp_unslash( $_POST['noyona_ot_url'] ) ) : '';
			$tracking_note   = isset( $_POST['noyona_ot_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['noyona_ot_note'] ) ) : '';

			if ( '' === $tracking_url && '' !== $carrier_slug && '' !== $tracking_number ) {
				$tracking_url = $this->build_tracking_url( $carrier_slug, $tracking_number );
			}

			$order_object->update_meta_data( self::META_KEY_CARRIER, $carrier_slug );
			$order_object->update_meta_data( self::META_KEY_NUMBER, $tracking_number );
			$order_object->update_meta_data( self::META_KEY_URL, $tracking_url );
			$order_object->update_meta_data( self::META_KEY_NOTE, $tracking_note );
		}

		/**
		 * @return array<int, array<string, string|int>>
		 */
		private function collect_events_from_request() {
			if ( ! isset( $_POST['noyona_ot_events'] ) || ! is_array( $_POST['noyona_ot_events'] ) ) {
				return array();
			}

			$events_raw = wp_unslash( $_POST['noyona_ot_events'] );
			$labels     = isset( $events_raw['label'] ) && is_array( $events_raw['label'] ) ? $events_raw['label'] : array();
			$codes      = isset( $events_raw['code'] ) && is_array( $events_raw['code'] ) ? $events_raw['code'] : array();
			$notes      = isset( $events_raw['note'] ) && is_array( $events_raw['note'] ) ? $events_raw['note'] : array();
			$dates      = isset( $events_raw['date'] ) && is_array( $events_raw['date'] ) ? $events_raw['date'] : array();
			$manual     = isset( $events_raw['manual'] ) && is_array( $events_raw['manual'] ) ? $events_raw['manual'] : array();

			$events = array();
			foreach ( $labels as $index => $label_raw ) {
				$label = sanitize_text_field( (string) $label_raw );
				if ( '' === $label ) {
					continue;
				}

				$code = isset( $codes[ $index ] ) ? sanitize_key( (string) $codes[ $index ] ) : '';
				if ( '' === $code ) {
					$code = sanitize_title( $label );
				}

				$local_date = isset( $dates[ $index ] ) ? (string) $dates[ $index ] : '';
				$events[]   = array(
					'code'           => $code,
					'label'          => $label,
					'note'           => isset( $notes[ $index ] ) ? sanitize_textarea_field( (string) $notes[ $index ] ) : '',
					'event_date_gmt' => $this->local_input_to_gmt( $local_date ),
					'is_manual'      => ( isset( $manual[ $index ] ) && '0' !== (string) $manual[ $index ] ) ? 1 : 0,
				);
			}

			return $this->normalize_events( $events );
		}

		/**
		 * @return void
		 */
		public function register_custom_statuses() {
			$status_labels = $this->get_custom_status_registry();
			foreach ( $status_labels as $status_slug => $label ) {
				register_post_status(
					'wc-' . $status_slug,
					array(
						'label'                     => $label,
						'public'                    => true,
						'exclude_from_search'       => false,
						'show_in_admin_all_list'    => true,
						'show_in_admin_status_list' => true,
						'label_count'               => _n_noop(
							$label . ' <span class="count">(%s)</span>',
							$label . ' <span class="count">(%s)</span>',
							'noyona-childtheme'
						),
					)
				);
			}
		}

		/**
		 * @param array<string, string> $statuses Existing statuses.
		 * @return array<string, string>
		 */
		public function inject_custom_status_labels( $statuses ) {
			$custom = $this->get_custom_status_registry();
			$merged = array();

			foreach ( (array) $statuses as $status_key => $status_label ) {
				$merged[ $status_key ] = $status_label;
				if ( 'wc-processing' !== $status_key ) {
					continue;
				}

				foreach ( $custom as $slug => $label ) {
					$merged[ 'wc-' . $slug ] = $label;
				}
			}

			if ( empty( $merged ) ) {
				return (array) $statuses;
			}

			// Ensure custom statuses exist even if wc-processing is missing.
			foreach ( $custom as $slug => $label ) {
				$key = 'wc-' . $slug;
				if ( isset( $merged[ $key ] ) ) {
					continue;
				}
				$merged[ $key ] = $label;
			}

			return $merged;
		}

		/**
		 * @param array<int, string> $statuses Report statuses.
		 * @return array<int, string>
		 */
		public function register_statuses_for_reports( $statuses ) {
			$statuses = is_array( $statuses ) ? $statuses : array();
			foreach ( array_keys( $this->get_custom_status_registry() ) as $slug ) {
				if ( in_array( $slug, $statuses, true ) ) {
					continue;
				}
				$statuses[] = $slug;
			}

			return $statuses;
		}

		/**
		 * @return array<string, string>
		 */
		private function get_custom_status_registry() {
			return array(
				'to-ship'          => __( 'To ship', 'noyona-childtheme' ),
				'to-receive'       => __( 'To receive', 'noyona-childtheme' ),
				'at-hub'           => __( 'At hub', 'noyona-childtheme' ),
				'rider-assigned'   => __( 'Rider assigned', 'noyona-childtheme' ),
				'out-for-delivery' => __( 'Out for delivery', 'noyona-childtheme' ),
			);
		}

		/**
		 * @return array<string, string>
		 */
		public function get_stage_to_status_map() {
			return array(
				'to-pay'        => 'pending',
				'to-ship'       => 'to-ship',
				'to-receive'    => 'to-receive',
				'at-hub'        => 'at-hub',
				'out-for-delivery' => 'out-for-delivery',
				'complete'      => 'completed',
				'cancel-refund' => 'cancelled',
			);
		}

		/**
		 * @param string $stage Stage slug.
		 * @return bool
		 */
		private function stage_requires_payment( $stage ) {
			return in_array( sanitize_key( (string) $stage ), array( 'to-ship', 'to-receive', 'at-hub', 'out-for-delivery', 'complete' ), true );
		}

		/**
		 * Admin-focused stage options for detailed logistics updates.
		 *
		 * @return array<string, string>
		 */
		private function get_admin_stage_options() {
			return array(
				'to-pay'           => __( 'To Pay', 'noyona-childtheme' ),
				'to-ship'          => __( 'To Ship', 'noyona-childtheme' ),
				'to-receive'       => __( 'Courier picked up', 'noyona-childtheme' ),
				'at-hub'           => __( 'At hub', 'noyona-childtheme' ),
				'out-for-delivery' => __( 'Out for delivery', 'noyona-childtheme' ),
				'complete'         => __( 'Complete', 'noyona-childtheme' ),
				'cancel-refund'    => __( 'Cancel / Refund', 'noyona-childtheme' ),
			);
		}

		/**
		 * Resolve admin stage based on exact current status.
		 *
		 * @param string $status_slug Order status slug.
		 * @return string
		 */
		private function get_admin_stage_from_status( $status_slug ) {
			$status_slug = sanitize_key( (string) $status_slug );
			$map         = array(
				'pending'          => 'to-pay',
				'on-hold'          => 'to-pay',
				'failed'           => 'to-pay',
				'processing'       => 'to-ship',
				'to-ship'          => 'to-ship',
				'to-receive'       => 'to-receive',
				'at-hub'           => 'at-hub',
				'rider-assigned'   => 'out-for-delivery',
				'out-for-delivery' => 'out-for-delivery',
				'shipped'          => 'out-for-delivery',
				'in-transit'       => 'out-for-delivery',
				'completed'        => 'complete',
				'cancelled'        => 'cancel-refund',
				'refunded'         => 'cancel-refund',
			);

			return isset( $map[ $status_slug ] ) ? $map[ $status_slug ] : 'to-pay';
		}

		/**
		 * @param WC_Order $order Order object.
		 * @param string   $stage Stage slug.
		 * @return bool
		 */
		private function can_set_stage_for_order( $order, $stage ) {
			if ( ! $this->stage_requires_payment( $stage ) ) {
				return true;
			}

			return $this->order_has_confirmed_payment( $order );
		}

		/**
		 * @param WC_Order|mixed $order Order object.
		 * @return bool
		 */
		private function order_has_confirmed_payment( $order ) {
			if ( ! $order instanceof WC_Order ) {
				return false;
			}

			if ( (float) $order->get_total() <= 0 ) {
				return true;
			}

			if ( $order->is_paid() ) {
				return true;
			}

			if ( $order->get_date_paid() instanceof WC_DateTime ) {
				return true;
			}

			if ( '' !== trim( (string) $order->get_transaction_id() ) ) {
				return true;
			}

			// Fallback for legacy data where paid markers are missing but order already entered logistics flow.
			$logistics_paid_fallback_statuses = array(
				'to-ship',
				'to-receive',
				'at-hub',
				'rider-assigned',
				'out-for-delivery',
				'shipped',
				'in-transit',
				'completed',
			);
			if ( $order->has_status( $logistics_paid_fallback_statuses ) ) {
				return true;
			}

			$paid_statuses = function_exists( 'wc_get_is_paid_statuses' ) ? array_map( 'sanitize_key', (array) wc_get_is_paid_statuses() ) : array( 'processing', 'completed' );
			if ( ! empty( $paid_statuses ) && $order->has_status( $paid_statuses ) ) {
				return true;
			}

			return false;
		}

		/**
		 * @param string $status_slug Order status.
		 * @return string
		 */
		private function get_stage_from_status( $status_slug ) {
			$status_slug = sanitize_key( (string) $status_slug );
			$map         = array(
				'pending'          => 'to-pay',
				'on-hold'          => 'to-pay',
				'failed'           => 'to-pay',
				'processing'       => 'to-ship',
				'to-ship'          => 'to-ship',
				'to-receive'       => 'to-receive',
				'at-hub'           => 'to-receive',
				'rider-assigned'   => 'to-receive',
				'out-for-delivery' => 'to-receive',
				'shipped'          => 'to-receive',
				'in-transit'       => 'to-receive',
				'completed'        => 'complete',
				'cancelled'        => 'cancel-refund',
				'refunded'         => 'cancel-refund',
			);

			return isset( $map[ $status_slug ] ) ? $map[ $status_slug ] : 'to-pay';
		}

		/**
		 * Supported carriers for enhanced-manual tracking links.
		 * URL templates use %s for the tracking number.
		 *
		 * @return array<string, array<string, string>>
		 */
		public function get_carrier_definitions() {
			return array(
				''      => array(
					'label'        => __( '— Select carrier —', 'noyona-childtheme' ),
					'url_template' => '',
				),
				'jnt'   => array(
					'label'        => __( 'J&T Express', 'noyona-childtheme' ),
					'url_template' => 'https://www.jtexpress.ph/track?billCode=%s',
				),
				'lbc'   => array(
					'label'        => __( 'LBC Express', 'noyona-childtheme' ),
					'url_template' => 'https://www.lbcexpress.com/track/?tracking_no=%s',
				),
				'other' => array(
					'label'        => __( 'Other', 'noyona-childtheme' ),
					'url_template' => '',
				),
			);
		}

		/**
		 * Build a carrier tracking URL from slug + number, if we know the template.
		 *
		 * @param string $carrier_slug Carrier slug.
		 * @param string $number       Tracking number.
		 * @return string Tracking URL, or empty string when not buildable.
		 */
		public function build_tracking_url( $carrier_slug, $number ) {
			$carrier_slug = sanitize_key( (string) $carrier_slug );
			$number       = trim( (string) $number );
			if ( '' === $carrier_slug || '' === $number ) {
				return '';
			}

			$carriers = $this->get_carrier_definitions();
			if ( ! isset( $carriers[ $carrier_slug ] ) ) {
				return '';
			}
			$template = isset( $carriers[ $carrier_slug ]['url_template'] ) ? (string) $carriers[ $carrier_slug ]['url_template'] : '';
			if ( '' === $template ) {
				return '';
			}
			return sprintf( $template, rawurlencode( $number ) );
		}

		/**
		 * Return carrier + tracking info for an order, with URL auto-filled when possible.
		 *
		 * @param WC_Order|int $order Order object or ID.
		 * @return array{carrier:string,label:string,number:string,url:string,note:string,has_tracking:bool}
		 */
		public function get_carrier_info_for_order( $order ) {
			$empty = array(
				'carrier'      => '',
				'label'        => '',
				'number'       => '',
				'url'          => '',
				'note'         => '',
				'has_tracking' => false,
			);

			$order_object = $this->ensure_order( $order );
			if ( ! $order_object ) {
				return $empty;
			}

			$carrier = sanitize_key( (string) $order_object->get_meta( self::META_KEY_CARRIER ) );
			$number  = trim( (string) $order_object->get_meta( self::META_KEY_NUMBER ) );
			$url     = trim( (string) $order_object->get_meta( self::META_KEY_URL ) );
			$note    = (string) $order_object->get_meta( self::META_KEY_NOTE );

			if ( '' === $url ) {
				$url = $this->build_tracking_url( $carrier, $number );
			}

			$carriers = $this->get_carrier_definitions();
			$label    = isset( $carriers[ $carrier ]['label'] ) ? (string) $carriers[ $carrier ]['label'] : '';

			return array(
				'carrier'      => $carrier,
				'label'        => $label,
				'number'       => $number,
				'url'          => $url,
				'note'         => $note,
				'has_tracking' => ( '' !== $number && '' !== $url ),
			);
		}

		/**
		 * @param WP_Post $post Post object.
		 * @return void
		 */
		public function add_tracking_metabox( $post ) {
			add_meta_box(
				'noyona-order-tracking',
				__( 'Noyona Order Tracking', 'noyona-childtheme' ),
				array( $this, 'render_tracking_metabox' ),
				'shop_order',
				'side',
				'default'
			);
		}

		/**
		 * @param WP_Post $post Post object.
		 * @return void
		 */
		public function render_tracking_metabox( $post ) {
			$order = $this->ensure_order( $post->ID );
			if ( ! $order ) {
				echo '<p>' . esc_html__( 'Order data unavailable.', 'noyona-childtheme' ) . '</p>';
				return;
			}

			$admin_stages  = $this->get_admin_stage_options();
			$current_stage = $this->get_admin_stage_from_status( (string) $order->get_status() );
			$events        = $this->get_events_for_order( $order, true );
			$carrier_info  = $this->get_carrier_info_for_order( $order );
			$carriers      = $this->get_carrier_definitions();
			$auto_url      = $this->build_tracking_url( $carrier_info['carrier'], $carrier_info['number'] );

			wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );
			?>
			<p>
				<label for="noyona-ot-stage"><strong><?php esc_html_e( 'Customer Stage', 'noyona-childtheme' ); ?></strong></label>
				<select id="noyona-ot-stage" name="noyona_ot_stage" style="width:100%;margin-top:6px;">
					<?php foreach ( $admin_stages as $stage_key => $stage_label ) : ?>
						<option value="<?php echo esc_attr( $stage_key ); ?>" <?php selected( $stage_key, $current_stage ); ?>>
							<?php echo esc_html( (string) $stage_label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</p>

			<hr style="margin:14px 0;border:0;border-top:1px solid #e2e2e2;">
			<p><strong><?php esc_html_e( 'Carrier Tracking', 'noyona-childtheme' ); ?></strong></p>
			<p style="margin:0 0 8px;color:#666;font-size:11px;">
				<?php esc_html_e( 'Paste the tracking number from J&T / LBC once. Customer gets a "Track Package" button in their account.', 'noyona-childtheme' ); ?>
			</p>
			<p>
				<label for="noyona-ot-carrier" style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Carrier', 'noyona-childtheme' ); ?></label>
				<select id="noyona-ot-carrier" name="noyona_ot_carrier" style="width:100%;">
					<?php foreach ( $carriers as $slug => $def ) : ?>
						<option value="<?php echo esc_attr( (string) $slug ); ?>" <?php selected( (string) $slug, $carrier_info['carrier'] ); ?>>
							<?php echo esc_html( (string) $def['label'] ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</p>
			<p>
				<label for="noyona-ot-number" style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Tracking number', 'noyona-childtheme' ); ?></label>
				<input type="text" id="noyona-ot-number" name="noyona_ot_number" value="<?php echo esc_attr( $carrier_info['number'] ); ?>" style="width:100%;">
			</p>
			<p>
				<label for="noyona-ot-url" style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Tracking URL (leave blank to auto-build for J&T / LBC)', 'noyona-childtheme' ); ?></label>
				<input type="url" id="noyona-ot-url" name="noyona_ot_url" value="<?php echo esc_attr( $carrier_info['url'] ); ?>" placeholder="<?php echo esc_attr( $auto_url ); ?>" style="width:100%;">
			</p>
			<p>
				<label for="noyona-ot-note" style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Tracking note (optional)', 'noyona-childtheme' ); ?></label>
				<textarea id="noyona-ot-note" name="noyona_ot_note" rows="2" style="width:100%;"><?php echo esc_textarea( $carrier_info['note'] ); ?></textarea>
			</p>
			<?php if ( $carrier_info['has_tracking'] ) : ?>
				<p style="margin:0 0 12px;">
					<a href="<?php echo esc_url( $carrier_info['url'] ); ?>" target="_blank" rel="noopener noreferrer" class="button button-secondary" style="width:100%;text-align:center;">
						<?php esc_html_e( 'Open tracking page ↗', 'noyona-childtheme' ); ?>
					</a>
				</p>
			<?php endif; ?>
			<hr style="margin:14px 0;border:0;border-top:1px solid #e2e2e2;">

			<p><strong><?php esc_html_e( 'Timeline Events', 'noyona-childtheme' ); ?></strong></p>
			<div id="noyona-ot-events-wrap">
				<?php foreach ( $events as $index => $event ) : ?>
					<?php $this->render_event_row( $event, (int) $index ); ?>
				<?php endforeach; ?>
			</div>
			<p>
				<button type="button" class="button" id="noyona-ot-add-event"><?php esc_html_e( 'Add Event', 'noyona-childtheme' ); ?></button>
			</p>
			<script>
			(function() {
				var addBtn = document.getElementById('noyona-ot-add-event');
				var wrap = document.getElementById('noyona-ot-events-wrap');
				if (!addBtn || !wrap) return;

				function eventRowHtml(index) {
					return [
						'<div class="noyona-ot-event-row" style="margin:0 0 10px;padding:10px;border:1px solid #e2e2e2;border-radius:8px;">',
						'<label style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;">Label</label>',
						'<input type="text" name="noyona_ot_events[label][]" value="" style="width:100%;margin-bottom:6px;">',
						'<label style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;">Code</label>',
						'<input type="text" name="noyona_ot_events[code][]" value="" placeholder="at-hub" style="width:100%;margin-bottom:6px;">',
						'<label style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;">Date / time (optional)</label>',
						'<input type="datetime-local" name="noyona_ot_events[date][]" value="" style="width:100%;margin-bottom:6px;">',
						'<label style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;">Note (optional)</label>',
						'<textarea name="noyona_ot_events[note][]" rows="2" style="width:100%;margin-bottom:6px;"></textarea>',
						'<input type="hidden" name="noyona_ot_events[manual][]" value="1">',
						'<button type="button" class="button-link-delete noyona-ot-remove-event">Remove</button>',
						'</div>'
					].join('');
				}

				addBtn.addEventListener('click', function() {
					var index = wrap.querySelectorAll('.noyona-ot-event-row').length;
					var holder = document.createElement('div');
					holder.innerHTML = eventRowHtml(index);
					wrap.appendChild(holder.firstChild);
				});

				wrap.addEventListener('click', function(event) {
					var remove = event.target.closest('.noyona-ot-remove-event');
					if (!remove) return;
					event.preventDefault();
					var row = remove.closest('.noyona-ot-event-row');
					if (row) row.remove();
				});
			})();
			</script>
			<?php
		}

		/**
		 * @param array<string, string|int> $event Event data.
		 * @param int                       $index Row index.
		 * @return void
		 */
		private function render_event_row( $event, $index ) {
			$label      = isset( $event['label'] ) ? (string) $event['label'] : '';
			$code       = isset( $event['code'] ) ? (string) $event['code'] : '';
			$date_local = isset( $event['event_date_gmt'] ) ? $this->gmt_to_local_input( (string) $event['event_date_gmt'] ) : '';
			$note       = isset( $event['note'] ) ? (string) $event['note'] : '';
			?>
			<div class="noyona-ot-event-row" style="margin:0 0 10px;padding:10px;border:1px solid #e2e2e2;border-radius:8px;">
				<label style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Label', 'noyona-childtheme' ); ?></label>
				<input type="text" name="noyona_ot_events[label][]" value="<?php echo esc_attr( $label ); ?>" style="width:100%;margin-bottom:6px;">
				<label style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Code', 'noyona-childtheme' ); ?></label>
				<input type="text" name="noyona_ot_events[code][]" value="<?php echo esc_attr( $code ); ?>" style="width:100%;margin-bottom:6px;">
				<label style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Date / time (optional)', 'noyona-childtheme' ); ?></label>
				<input type="datetime-local" name="noyona_ot_events[date][]" value="<?php echo esc_attr( $date_local ); ?>" style="width:100%;margin-bottom:6px;">
				<label style="display:block;font-size:11px;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Note (optional)', 'noyona-childtheme' ); ?></label>
				<textarea name="noyona_ot_events[note][]" rows="2" style="width:100%;margin-bottom:6px;"><?php echo esc_textarea( $note ); ?></textarea>
				<input type="hidden" name="noyona_ot_events[manual][]" value="1">
				<button type="button" class="button-link-delete noyona-ot-remove-event"><?php esc_html_e( 'Remove', 'noyona-childtheme' ); ?></button>
			</div>
			<?php
		}

		/**
		 * @param int      $order_id Order ID.
		 * @param string   $from     Previous status.
		 * @param string   $to       New status.
		 * @param WC_Order $order    Order object.
		 * @return void
		 */
		public function capture_status_change_event( $order_id, $from, $to, $order ) {
			$order = $this->ensure_order( $order );
			if ( ! $order ) {
				return;
			}

			$event = $this->build_status_event( sanitize_key( (string) $to ) );
			if ( empty( $event ) ) {
				return;
			}

			$events = $this->get_events_for_order( $order, false );
			$last   = end( $events );
			if ( is_array( $last ) && isset( $last['code'] ) && (string) $last['code'] === (string) $event['code'] ) {
				return;
			}

			$events[] = $event;
			$order->update_meta_data( self::META_KEY_EVENTS, $this->normalize_events( $events ) );
			$order->save();
		}

		/**
		 * @param string $status_slug Status slug.
		 * @return array<string, string|int>
		 */
		private function build_status_event( $status_slug ) {
			$template = $this->get_default_timeline_template();
			$code     = $this->status_to_stage_code( $status_slug );
			if ( '' === $code ) {
				return array();
			}

			$label = isset( $template[ $code ] ) ? (string) $template[ $code ] : wc_get_order_status_name( $status_slug );
			if ( '' === trim( $label ) ) {
				$label = ucwords( str_replace( '-', ' ', $status_slug ) );
			}

			return array(
				'code'           => sanitize_key( $code ),
				'label'          => sanitize_text_field( $label ),
				'note'           => '',
				'event_date_gmt' => gmdate( 'Y-m-d H:i:s' ),
				'is_manual'      => 0,
			);
		}

		/**
		 * @return void
		 */
		public function register_admin_page() {
			add_submenu_page(
				'woocommerce',
				__( 'Order Tracking', 'noyona-childtheme' ),
				__( 'Order Tracking', 'noyona-childtheme' ),
				'manage_woocommerce',
				'noyona-order-tracking',
				array( $this, 'render_admin_page' )
			);
		}

		/**
		 * @return void
		 */
		public function render_admin_page() {
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_die( esc_html__( 'You are not allowed to access this page.', 'noyona-childtheme' ) );
			}

			$filters           = $this->get_order_status_filters();
			$selected_filter   = isset( $_GET['filter'] ) ? sanitize_key( wp_unslash( $_GET['filter'] ) ) : 'all';
			$page              = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1;
			$orders_per_page   = 20;
			$query_statuses    = array();
			if ( 'all' !== $selected_filter ) {
				$query_statuses = $this->get_query_statuses_for_filter( $selected_filter );
			}

			$query_args = array(
				'limit'    => $orders_per_page,
				'paginate' => true,
				'page'     => $page,
				'orderby'  => 'date',
				'order'    => 'DESC',
			);
			if ( ! empty( $query_statuses ) ) {
				$query_args['status'] = $query_statuses;
			}

			$result      = function_exists( 'wc_get_orders' ) ? wc_get_orders( $query_args ) : array();
			$orders      = array();
			$total_pages = 1;
			if ( is_object( $result ) && isset( $result->orders ) ) {
				$orders      = is_array( $result->orders ) ? $result->orders : array();
				$total_pages = isset( $result->max_num_pages ) ? max( 1, (int) $result->max_num_pages ) : 1;
			} elseif ( is_array( $result ) ) {
				$orders = $result;
			}

			$current_url = add_query_arg(
				array(
					'page'   => 'noyona-order-tracking',
					'filter' => $selected_filter,
					'paged'  => $page,
				),
				admin_url( 'admin.php' )
			);
			$notice_code = isset( $_GET['noyona_ot_notice'] ) ? sanitize_key( wp_unslash( $_GET['noyona_ot_notice'] ) ) : '';
			?>
			<div class="wrap">
				<h1><?php esc_html_e( 'Order Tracking Manager', 'noyona-childtheme' ); ?></h1>
				<?php if ( 'payment_required' === $notice_code ) : ?>
					<div class="notice notice-error"><p><?php esc_html_e( 'Order must be paid before moving to To Ship, To Receive, or Complete.', 'noyona-childtheme' ); ?></p></div>
				<?php elseif ( 'updated' === $notice_code ) : ?>
					<div class="notice notice-success"><p><?php esc_html_e( 'Order tracking updated.', 'noyona-childtheme' ); ?></p></div>
				<?php endif; ?>
				<form method="get" action="">
					<input type="hidden" name="page" value="noyona-order-tracking" />
					<label for="noyona-ot-filter"><?php esc_html_e( 'Filter', 'noyona-childtheme' ); ?></label>
					<select id="noyona-ot-filter" name="filter">
						<option value="all"<?php selected( 'all', $selected_filter ); ?>><?php esc_html_e( 'All', 'noyona-childtheme' ); ?></option>
						<?php foreach ( $filters as $filter_key => $filter_config ) : ?>
							<option value="<?php echo esc_attr( $filter_key ); ?>"<?php selected( $filter_key, $selected_filter ); ?>>
								<?php echo esc_html( (string) $filter_config['label'] ); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<button type="submit" class="button"><?php esc_html_e( 'Apply', 'noyona-childtheme' ); ?></button>
				</form>

				<table class="widefat striped" style="margin-top:16px;">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Order', 'noyona-childtheme' ); ?></th>
							<th><?php esc_html_e( 'Customer', 'noyona-childtheme' ); ?></th>
							<th><?php esc_html_e( 'Current Status', 'noyona-childtheme' ); ?></th>
							<th><?php esc_html_e( 'Latest Event', 'noyona-childtheme' ); ?></th>
							<th><?php esc_html_e( 'Quick Update', 'noyona-childtheme' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php if ( ! empty( $orders ) ) : ?>
						<?php foreach ( $orders as $order ) : ?>
							<?php if ( ! $order instanceof WC_Order ) : ?>
								<?php continue; ?>
							<?php endif; ?>
							<?php
							$order_id      = (int) $order->get_id();
							$customer_name = trim( (string) $order->get_billing_first_name() . ' ' . (string) $order->get_billing_last_name() );
							$status_slug   = sanitize_key( (string) $order->get_status() );
							$latest_event  = '';
							$events        = $this->get_events_for_order( $order, true );
							if ( ! empty( $events ) ) {
								$last_item = end( $events );
								if ( is_array( $last_item ) ) {
									$latest_event = isset( $last_item['label'] ) ? (string) $last_item['label'] : '';
									$date_label   = isset( $last_item['event_date_gmt'] ) ? $this->format_date_label( (string) $last_item['event_date_gmt'] ) : '';
									if ( '' !== $date_label ) {
										$latest_event = trim( $latest_event . ' - ' . $date_label );
									}
								}
							}
							?>
							<tr>
								<td>#<?php echo esc_html( (string) $order->get_order_number() ); ?></td>
								<td><?php echo esc_html( '' !== $customer_name ? $customer_name : __( 'Guest', 'noyona-childtheme' ) ); ?></td>
								<td><?php echo esc_html( wc_get_order_status_name( $status_slug ) ); ?></td>
								<td><?php echo esc_html( '' !== $latest_event ? $latest_event : __( 'No events yet', 'noyona-childtheme' ) ); ?></td>
								<td>
									<?php $row_carrier_info = $this->get_carrier_info_for_order( $order ); ?>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:grid;gap:6px;max-width:300px;">
										<?php wp_nonce_field( 'noyona_ot_quick_update_' . $order_id, 'noyona_ot_quick_nonce' ); ?>
										<input type="hidden" name="action" value="noyona_ot_quick_update" />
										<input type="hidden" name="order_id" value="<?php echo esc_attr( (string) $order_id ); ?>" />
										<input type="hidden" name="redirect_to" value="<?php echo esc_url( $current_url ); ?>" />
										<select name="stage">
											<?php
											$admin_stages = $this->get_admin_stage_options();
											$current_admin_stage = $this->get_admin_stage_from_status( $status_slug );
											?>
											<?php foreach ( $admin_stages as $stage_key => $stage_label ) : ?>
												<option value="<?php echo esc_attr( $stage_key ); ?>"<?php selected( $stage_key, $current_admin_stage ); ?>>
													<?php echo esc_html( (string) $stage_label ); ?>
												</option>
											<?php endforeach; ?>
										</select>
										<input type="text" name="event_label" placeholder="<?php esc_attr_e( 'Optional custom event label', 'noyona-childtheme' ); ?>" />
										<input type="datetime-local" name="event_date" />
										<select name="carrier">
											<?php foreach ( $this->get_carrier_definitions() as $carrier_slug => $carrier_def ) : ?>
												<option value="<?php echo esc_attr( (string) $carrier_slug ); ?>"<?php selected( (string) $carrier_slug, $row_carrier_info['carrier'] ); ?>>
													<?php echo esc_html( (string) $carrier_def['label'] ); ?>
												</option>
											<?php endforeach; ?>
										</select>
										<input type="text" name="tracking_number" value="<?php echo esc_attr( $row_carrier_info['number'] ); ?>" placeholder="<?php esc_attr_e( 'Tracking number (optional)', 'noyona-childtheme' ); ?>" />
										<button type="submit" class="button button-primary"><?php esc_html_e( 'Save', 'noyona-childtheme' ); ?></button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr>
							<td colspan="5"><?php esc_html_e( 'No orders found for this filter.', 'noyona-childtheme' ); ?></td>
						</tr>
					<?php endif; ?>
					</tbody>
				</table>
				<?php if ( $total_pages > 1 ) : ?>
					<div style="margin-top:14px;">
						<?php
						echo wp_kses_post(
							paginate_links(
								array(
									'base'    => add_query_arg(
										array(
											'page'   => 'noyona-order-tracking',
											'filter' => $selected_filter,
											'paged'  => '%#%',
										),
										admin_url( 'admin.php' )
									),
									'format'  => '',
									'current' => $page,
									'total'   => $total_pages,
								)
							)
						);
						?>
					</div>
				<?php endif; ?>
			</div>
			<?php
		}

		/**
		 * @return void
		 */
		public function handle_quick_update() {
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_die( esc_html__( 'Unauthorized', 'noyona-childtheme' ) );
			}

			$order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
			$nonce    = isset( $_POST['noyona_ot_quick_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['noyona_ot_quick_nonce'] ) ) : '';
			if ( $order_id < 1 || '' === $nonce || ! wp_verify_nonce( $nonce, 'noyona_ot_quick_update_' . $order_id ) ) {
				wp_die( esc_html__( 'Invalid request.', 'noyona-childtheme' ) );
			}

			$order = $this->ensure_order( $order_id );
			if ( ! $order ) {
				wp_die( esc_html__( 'Order not found.', 'noyona-childtheme' ) );
			}

			$stage      = isset( $_POST['stage'] ) ? sanitize_key( wp_unslash( $_POST['stage'] ) ) : '';
			$status_map = $this->get_stage_to_status_map();
			if ( ! $this->can_set_stage_for_order( $order, $stage ) ) {
				$redirect_to = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : '';
				if ( '' === $redirect_to ) {
					$redirect_to = add_query_arg( 'page', 'noyona-order-tracking', admin_url( 'admin.php' ) );
				}
				wp_safe_redirect( add_query_arg( 'noyona_ot_notice', 'payment_required', $redirect_to ) );
				exit;
			}

			if ( isset( $status_map[ $stage ] ) ) {
				$next_status = sanitize_key( (string) $status_map[ $stage ] );
				if ( '' !== $next_status && $next_status !== $order->get_status() ) {
					$order->set_status( $next_status );
				}
			}

			$events      = $this->get_events_for_order( $order, true );
			$event_label = isset( $_POST['event_label'] ) ? sanitize_text_field( wp_unslash( $_POST['event_label'] ) ) : '';
			if ( '' !== $event_label ) {
				$events[] = array(
					'code'           => sanitize_title( $event_label ),
					'label'          => $event_label,
					'note'           => '',
					'event_date_gmt' => $this->local_input_to_gmt( isset( $_POST['event_date'] ) ? (string) wp_unslash( $_POST['event_date'] ) : '' ),
					'is_manual'      => 1,
				);
			}

			$order->update_meta_data( self::META_KEY_EVENTS, $this->normalize_events( $events ) );

			if ( isset( $_POST['carrier'] ) || isset( $_POST['tracking_number'] ) ) {
				$carriers     = $this->get_carrier_definitions();
				$carrier_slug = isset( $_POST['carrier'] ) ? sanitize_key( wp_unslash( $_POST['carrier'] ) ) : '';
				if ( ! isset( $carriers[ $carrier_slug ] ) ) {
					$carrier_slug = '';
				}
				$tracking_number = isset( $_POST['tracking_number'] ) ? sanitize_text_field( wp_unslash( $_POST['tracking_number'] ) ) : '';

				$existing_url = trim( (string) $order->get_meta( self::META_KEY_URL ) );
				$new_url      = $existing_url;
				if ( '' === $new_url && '' !== $carrier_slug && '' !== $tracking_number ) {
					$new_url = $this->build_tracking_url( $carrier_slug, $tracking_number );
				}

				$order->update_meta_data( self::META_KEY_CARRIER, $carrier_slug );
				$order->update_meta_data( self::META_KEY_NUMBER, $tracking_number );
				$order->update_meta_data( self::META_KEY_URL, $new_url );
			}

			$order->save();

			$redirect_to = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : '';
			if ( '' === $redirect_to ) {
				$redirect_to = add_query_arg( 'page', 'noyona-order-tracking', admin_url( 'admin.php' ) );
			}

			wp_safe_redirect( add_query_arg( 'noyona_ot_notice', 'updated', $redirect_to ) );
			exit;
		}
	}
}

if ( ! function_exists( 'noyona_ot_get_order_status_filters' ) ) {
	/**
	 * @return array<string, array<string, mixed>>
	 */
	function noyona_ot_get_order_status_filters() {
		return Noyona_Order_Tracking::get_instance()->get_order_status_filters();
	}
}

if ( ! function_exists( 'noyona_ot_get_selected_filter' ) ) {
	/**
	 * @param string $default Default filter.
	 * @return string
	 */
	function noyona_ot_get_selected_filter( $default = 'to-pay' ) {
		return Noyona_Order_Tracking::get_instance()->get_selected_filter( $default );
	}
}

if ( ! function_exists( 'noyona_ot_get_query_statuses_for_filter' ) ) {
	/**
	 * @param string $filter_key Filter key.
	 * @return array<int, string>
	 */
	function noyona_ot_get_query_statuses_for_filter( $filter_key ) {
		return Noyona_Order_Tracking::get_instance()->get_query_statuses_for_filter( $filter_key );
	}
}

if ( ! function_exists( 'noyona_ot_get_timeline_rows' ) ) {
	/**
	 * @param WC_Order|int $order Order object or ID.
	 * @return array<int, array<string, string>>
	 */
	function noyona_ot_get_timeline_rows( $order ) {
		return Noyona_Order_Tracking::get_instance()->get_timeline_rows( $order );
	}
}

if ( ! function_exists( 'noyona_ot_get_order_events' ) ) {
	/**
	 * @param WC_Order|int $order Order object or ID.
	 * @param bool         $with_fallback Include generated fallback events.
	 * @return array<int, array<string, string|int>>
	 */
	function noyona_ot_get_order_events( $order, $with_fallback = true ) {
		return Noyona_Order_Tracking::get_instance()->get_events_for_order( $order, $with_fallback );
	}
}

if ( ! function_exists( 'noyona_ot_get_carrier_info' ) ) {
	/**
	 * Get carrier tracking info for an order (carrier slug, label, number, URL, note,
	 * and a `has_tracking` flag that callers use to decide whether to render UI).
	 *
	 * @param WC_Order|int $order Order object or ID.
	 * @return array{carrier:string,label:string,number:string,url:string,note:string,has_tracking:bool}
	 */
	function noyona_ot_get_carrier_info( $order ) {
		return Noyona_Order_Tracking::get_instance()->get_carrier_info_for_order( $order );
	}
}

