<?php
/**
 * Plugin Name: Noyona Order Tracking
 * Description: Admin-managed order tracking stages and timeline events for My Account order history.
 * Version: 1.1.0
 * Author: Noyona Team
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$not_class_file = trailingslashit( plugin_dir_path( __FILE__ ) ) . 'noyona-order-tracking/class-noyona-order-tracking.php';
if ( ! file_exists( $not_class_file ) && defined( 'WPMU_PLUGIN_DIR' ) ) {
	$not_class_file = WPMU_PLUGIN_DIR . '/noyona-order-tracking/class-noyona-order-tracking.php';
}
if ( file_exists( $not_class_file ) ) {
	require_once $not_class_file;
	Noyona_Order_Tracking::get_instance();
}

